define _editor=vi
set sqlprompt _user'@'_connect_identifier>
set pagesize 3000
set linesize 130
